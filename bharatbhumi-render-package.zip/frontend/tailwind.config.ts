import type { Config } from "tailwindcss";
export default { content: ["./app/**/*.tsx","./components/**/*.tsx"],
 theme:{extend:{colors:{saffron:"#E8791B",india:"#12783A",navy:"#0F2A4A",paper:"#F5F7FA"},fontFamily:{sans:["Inter","system-ui","sans-serif"]}}}, plugins:[] } satisfies Config;
