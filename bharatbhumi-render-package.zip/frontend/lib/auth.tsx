"use client";
import {createContext,useContext,useEffect,useState} from "react";import {api,setToken,clearToken,getToken} from "./api";
export type Role="Public"|"Researcher"|"Policy Maker"|"Administrator";
export type User={name:string;email:string;role:Role;org:string;photo?:string};
const label:Record<string,Role>={PUBLIC:"Public",RESEARCHER:"Researcher",POLICY_MAKER:"Policy Maker",ADMIN:"Administrator"};
const code:Record<string,string>={"Public":"PUBLIC","Researcher":"RESEARCHER","Policy Maker":"POLICY_MAKER"};
const Ctx=createContext<any>(null);export const useAuth=()=>useContext(Ctx);
const conv=(u:any):User=>({name:u.name,email:u.email,org:u.org||"",role:label[u.role]||"Public",photo:(typeof window!=="undefined"&&localStorage.getItem("bb_photo_"+u.email))||""});
export function AuthProvider({children}:{children:React.ReactNode}){
 const [user,setUser]=useState<User|null>(null);const [ready,setReady]=useState(false);const [theme,setT]=useState<"light"|"dark">("light");
 useEffect(()=>{(async()=>{try{const t=localStorage.getItem("bb_theme") as any;if(t)setTheme(t);if(getToken())setUser(conv(await api("/api/auth/me")))}catch{clearToken()}setReady(true)})()},[]);
 const setTheme=(t:"light"|"dark")=>{setT(t);document.documentElement.classList.toggle("dark",t==="dark");try{localStorage.setItem("bb_theme",t)}catch{}};
 const login=async(email:string,password:string):Promise<string|null>=>{try{const r=await api("/api/auth/login",{method:"POST",body:{email,password}});setToken(r.token);setUser(conv(r.user));return null}catch(e:any){return e.message}};
 const signup=async(f:{name:string;email:string;org:string;password:string;role:Role}):Promise<string|null>=>{try{await api("/api/auth/register",{method:"POST",body:{...f,role:code[f.role]}});return null}catch(e:any){return e.message}};
 const updateUser=async(p:Partial<User>)=>{if(!user)return false;try{const n={...user,...p};if(p.name!==undefined||p.org!==undefined)await api("/api/auth/me",{method:"PUT",body:{name:n.name,org:n.org}});if(p.photo!==undefined)localStorage.setItem("bb_photo_"+user.email,p.photo||"");setUser(n);return true}catch{return false}};
 const logout=()=>{setUser(null);clearToken()};
 const deleteAccount=async()=>{try{await api("/api/auth/me",{method:"DELETE"})}catch{}logout()};
 return <Ctx.Provider value={{user,ready,theme,setTheme,login,signup,logout,updateUser,deleteAccount}}>{children}</Ctx.Provider>}
