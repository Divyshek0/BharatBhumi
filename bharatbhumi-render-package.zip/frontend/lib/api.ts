"use client";
import {useEffect,useState} from "react";
export const API="";
export const getToken=()=>typeof window!=="undefined"?localStorage.getItem("bb_token"):null;
export const setToken=(t:string)=>localStorage.setItem("bb_token",t);
export const clearToken=()=>localStorage.removeItem("bb_token");
export async function api<T=any>(path:string,opt:{method?:string;body?:any}={}):Promise<T>{
 const t=getToken();const r=await fetch(API+path,{method:opt.method||"GET",headers:{"Content-Type":"application/json",...(t?{Authorization:`Bearer ${t}`}:{})},body:opt.body?JSON.stringify(opt.body):undefined});
 const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||j.message||`Request failed (${r.status})`);return j}
export function useApi<T>(path:string,fallback:T,map?:(x:any)=>T){const [data,setD]=useState<T>(fallback);const [live,setLive]=useState(false);
 useEffect(()=>{setLive(false);setD(fallback);api(path).then(x=>{const v=map?map(x):x;if(Array.isArray(v)&&!v.length)return;setD(v);setLive(true)}).catch(()=>{})},[path]);return{data,live}}
