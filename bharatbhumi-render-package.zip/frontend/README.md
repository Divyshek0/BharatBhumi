# BharatBhumi (SIH 2026 · PS 26019)
Next.js 14 + TypeScript + Tailwind frontend.
```
npm install
npm run dev
```
Mock data: `lib/data.ts`. Pages: `/`, `/explorer`, `/login`, `/dashboard`. Replace mocks with backend API calls; add MapLibre/Leaflet in `/dashboard`.
