module.exports = {
  async rewrites() {
    const backend = process.env.BACKEND_HOST || "localhost:8080";
    return [{ source: "/api/:path*", destination: `http://${backend}/api/:path*` }];
  },
};
