"use client";
import {Head,Table,Guard} from "@/components/ui";import {apis} from "@/lib/data";
export default function P(){return(<Guard><Head title="API Hub" sub="Endpoints for integration with government and research systems"/><Table h={["Endpoint","Description","Format","Access"]} rows={apis}/></Guard>)}
