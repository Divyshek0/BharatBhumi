"use client";
import {Head,Table,Guard} from "@/components/ui";import {spaces} from "@/lib/data";
export default function P(){return(<Guard><Head title="Collaborative Workspaces" sub="Joint spaces for researchers, policymakers and agencies"/><Table h={["Workspace","Members","Partners","Status"]} rows={spaces}/></Guard>)}
