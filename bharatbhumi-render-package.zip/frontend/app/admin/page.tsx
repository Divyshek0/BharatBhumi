"use client";
import {Head,Guard,Table,Stat} from "@/components/ui";import {useApi} from "@/lib/api";
export default function P(){const{data,live}=useApi<any[]>("/api/admin/users",[]);const c=(r:string)=>data.filter(u=>u.role===r).length;
 return(<Guard roles={["Administrator"]}><Head title="Administration" sub="Registered users and roles (live from the backend)"/>
 <div className="mb-4 grid grid-cols-2 gap-4 md:grid-cols-4"><Stat l="Public" v={String(c("PUBLIC"))} i="👤"/><Stat l="Researchers" v={String(c("RESEARCHER"))} i="🔬"/><Stat l="Policy makers" v={String(c("POLICY_MAKER"))} i="🏛"/><Stat l="Admins" v={String(c("ADMIN"))} i="🛡"/></div>
 {live?<Table h={["ID","Name","Email","Role"]} rows={data.map(u=>[String(u.id),u.name,u.email,u.role])}/>:<p className="text-sm text-slate-500">Loading users…</p>}</Guard>)}
