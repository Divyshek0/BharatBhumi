"use client";
import {Head,Table,Guard} from "@/components/ui";import {papers} from "@/lib/data";
export default function P(){return(<Guard><Head title="Research Hub" sub="Papers, briefs and case studies on land governance"/><Table h={["Title","Institution","Year","Type"]} rows={papers}/></Guard>)}
