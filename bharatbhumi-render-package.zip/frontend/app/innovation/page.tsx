"use client";
import {Head,Table,Guard} from "@/components/ui";import {innov} from "@/lib/data";
export default function P(){return(<Guard><Head title="Innovation Portal" sub="Hackathons, grants, pilots and competitions"/><Table h={["Programme","Type","Status","Deadline"]} rows={innov}/></Guard>)}
