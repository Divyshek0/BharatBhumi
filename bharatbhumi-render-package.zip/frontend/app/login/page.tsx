"use client";
import {useState} from "react";import {useRouter} from "next/navigation";import Link from "next/link";import {useAuth} from "@/lib/auth";
export default function Login(){const r=useRouter();const{login,signup}=useAuth();
 const [tab,setTab]=useState<"in"|"up">("in");const [done,setDone]=useState(false);const [err,setErr]=useState("");const [busy,setBusy]=useState(false);
 const [f,setF]=useState({name:"",email:"",org:"",password:"",role:"Researcher"});const s=(k:string)=>(e:any)=>setF({...f,[k]:e.target.value});
 const submit=async()=>{setErr("");setBusy(true);
  if(tab==="in"){const e=await login(f.email,f.password);e?setErr(e):r.push("/dashboard")}
  else{if(!f.name||!f.email||f.password.length<8){setBusy(false);return setErr("Fill all fields; password min 8 characters.")}const e=await signup(f as any);e?setErr(e):setDone(true)}setBusy(false)};
 return(<div className="grid min-h-screen md:grid-cols-[1.1fr_1fr]"><div className="mesh relative hidden flex-col justify-between p-12 text-white md:flex">
  <Link href="/" className="flex items-center gap-3"><span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-saffron to-amber-400 font-bold">भ</span><b className="text-lg">BharatBhumi</b></Link>
  <div><h2 className="text-4xl font-bold leading-tight">Evidence-based land governance, built for collaboration.</h2><div className="mt-8 grid grid-cols-3 gap-3 text-center">{[["6.4L+","Villages"],["120+","Datasets"],["3,850","Papers"]].map(([n,l])=>(<div key={l} className="rounded-2xl border border-white/15 bg-white/10 p-4 backdrop-blur"><div className="text-2xl font-bold">{n}</div><div className="text-xs text-slate-300">{l}</div></div>))}</div></div>
  <p className="text-xs text-slate-400">Smart India Hackathon 2026 · PS 26019</p></div>
 <div className="grid place-items-center bg-white p-8"><div className="w-full max-w-sm">{done?<div className="text-center"><div className="text-5xl">✅</div><h3 className="mt-3 text-xl font-bold text-navy">Account created</h3><p className="my-3 text-sm text-slate-500">Your account is ready. Please sign in.</p><button className="btn" onClick={()=>{setDone(false);setTab("in")}}>Go to sign in</button></div>:<>
  <h1 className="text-2xl font-bold text-navy">{tab==="in"?"Welcome back":"Create your account"}</h1><p className="mb-6 mt-1 text-sm text-slate-500">{tab==="in"?"Sign in to your workspace.":"Choose the role that fits you. Administrator accounts are provisioned by the system."}</p>
  <div className="space-y-3">{tab==="up"&&<><input className="inp" placeholder="Full name" onChange={s("name")}/><input className="inp" placeholder="Institution / organisation" onChange={s("org")}/><select className="inp" value={f.role} onChange={s("role")}><option>Public</option><option>Researcher</option><option>Policy Maker</option></select></>}
   <input className="inp" placeholder="Email" value={f.email} onChange={s("email")}/><input type="password" className="inp" placeholder="Password" value={f.password} onChange={s("password")} onKeyDown={e=>e.key==="Enter"&&submit()}/>
   {err&&<p className="text-sm text-red-600">{err}</p>}<button disabled={busy} className="btn w-full disabled:opacity-60" onClick={submit}>{busy?"Please wait…":tab==="in"?"Sign in":"Create account"}</button></div>
  <p className="mt-4 text-center text-sm text-slate-500">{tab==="in"?"New here?":"Already registered?"} <button className="font-semibold text-navy underline" onClick={()=>{setTab(tab==="in"?"up":"in");setErr("")}}>{tab==="in"?"Create account":"Sign in"}</button></p></>}</div></div></div>)}
