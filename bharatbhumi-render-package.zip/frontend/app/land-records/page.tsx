"use client";
import {Head,Table,Guard} from "@/components/ui";import {records} from "@/lib/data";
export default function P(){return(<Guard roles={["Policy Maker","Administrator"]}><Head title="Land Records" sub="Digitisation and verification status (restricted – Policy Makers & Admins)"/><Table h={["Record ID","Location","Type","Status","Verification","Updated"]} rows={records}/></Guard>)}
