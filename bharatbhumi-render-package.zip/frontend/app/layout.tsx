import "./globals.css";import type {Metadata} from "next";import Shell from "@/components/Shell";import {AuthProvider} from "@/lib/auth";
export const metadata:Metadata={title:"BharatBhumi – National Land Governance Platform",description:"Research and policy innovation platform for land governance in India"};
export default function L({children}:{children:React.ReactNode}){return(<html lang="en"><body><AuthProvider><Shell>{children}</Shell></AuthProvider></body></html>)}
