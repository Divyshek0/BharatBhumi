"use client";
import {Head,Table} from "@/components/ui";import {datasets} from "@/lib/data";import {useApi} from "@/lib/api";import {useAuth} from "@/lib/auth";
export default function P(){const{user}=useAuth();const path=user&&user.role!=="Public"?"/api/research/datasets":"/api/public/datasets";
 const{data,live}=useApi<string[][]>(path,datasets,(x:any[])=>x.map(d=>[d.title,d.source||"—",d.category||"—",(d.access||"PUBLIC")==="PUBLIC"?"Public":"Researcher",d.records_count?Number(d.records_count).toLocaleString("en-IN"):"—",String(d.updated_at||"—")]));
 return(<><Head title="Land Data" sub="Catalogue of integrated datasets across agencies"/><p className="mb-3 text-xs text-slate-500">{live?"🟢 Live from database":"⚪ Demo data (backend offline or empty)"}{!user&&" · sign in to see researcher-level datasets"}</p><Table h={["Dataset","Source","Category","Access","Records","Updated"]} rows={data}/></>)}
