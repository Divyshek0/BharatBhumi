"use client";
import {useEffect,useRef,useState} from "react";import "leaflet/dist/leaflet.css";import {Head} from "@/components/ui";import {states,layers,geo} from "@/lib/data";
export default function P(){
 const el=useRef<HTMLDivElement>(null);const map=useRef<any>(null);const grp=useRef<any>(null);const tiles=useRef<any>({});const Lr=useRef<any>(null);
 const [sel,setSel]=useState(states[0]);const [base,setBase]=useState<"street"|"sat">("street");const [metric,setMetric]=useState<"dig"|"rec">("dig");const [on,setOn]=useState<string[]>([layers[0]]);
 useEffect(()=>{let dead=false;(async()=>{const L=(await import("leaflet")).default;if(dead||!el.current||map.current)return;Lr.current=L;
  const m=L.map(el.current,{zoomControl:true}).setView([22.5,80],5);map.current=m;
  tiles.current.street=L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",{attribution:"© OpenStreetMap"}).addTo(m);
  tiles.current.sat=L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",{attribution:"Esri"});
  grp.current=L.layerGroup().addTo(m);setSel(s=>[...s] as any)})();return()=>{dead=true;map.current?.remove();map.current=null}},[]);
 useEffect(()=>{const m=map.current;if(!m)return;const t=tiles.current;m.removeLayer(base==="sat"?t.street:t.sat);t[base].addTo(m)},[base,sel]);
 useEffect(()=>{const L=Lr.current,g=grp.current;if(!L||!g)return;g.clearLayers();
  states.forEach(s=>{const ll=geo[s[0]];if(!ll)return;const val=metric==="dig"?s[1]:parseFloat(s[2])*4;const col=s[1]>90?"#0F2A4A":s[1]>80?"#2563eb":s[1]>70?"#E8791B":"#dc2626";
   L.circleMarker(ll,{radius:Math.max(8,val/4),color:col,fillColor:col,fillOpacity:.55,weight:sel[0]===s[0]?4:1.5}).bindTooltip(`${s[0]} · ${s[1]}% digitised`).on("click",()=>setSel(s)).addTo(g)})},[metric,sel,base]);
 return(<><Head title="GIS Explorer" sub="Interactive map of land-record digitisation and land-use layers across India"/>
 <div className="grid gap-4 lg:grid-cols-[240px_1fr_260px]">
  <div className="space-y-4"><div className="card"><h3 className="mb-2 text-sm font-semibold text-navy">Base map</h3><div className="flex rounded-xl bg-slate-100 p-1 text-sm">{(["street","sat"] as const).map(b=><button key={b} onClick={()=>setBase(b)} className={`flex-1 rounded-lg py-1.5 ${base===b?"bg-white font-semibold shadow":""}`}>{b==="sat"?"Satellite":"Street"}</button>)}</div>
   <h3 className="mb-2 mt-4 text-sm font-semibold text-navy">Bubble size</h3><div className="flex rounded-xl bg-slate-100 p-1 text-sm">{([["dig","Digitised %"],["rec","Parcels"]] as const).map(([k,n])=><button key={k} onClick={()=>setMetric(k)} className={`flex-1 rounded-lg py-1.5 ${metric===k?"bg-white font-semibold shadow":""}`}>{n}</button>)}</div></div>
   <div className="card"><h3 className="mb-2 text-sm font-semibold text-navy">Layers</h3>{layers.map(l=>(<label key={l} className="flex items-center gap-2 py-1 text-sm"><input type="checkbox" checked={on.includes(l)} onChange={()=>setOn(on.includes(l)?on.filter(x=>x!==l):[...on,l])}/>{l}</label>))}<p className="mt-2 text-[11px] text-slate-400">Layer toggles are UI-ready; wire to WMS/GeoJSON from your backend.</p></div></div>
  <div className="card overflow-hidden p-0"><div ref={el} className="z-0 h-[560px] w-full"/></div>
  <div className="space-y-4"><div className="card"><h3 className="text-lg font-bold text-navy">{sel[0]}</h3><dl className="mt-3 space-y-3 text-sm">{[["Digitised",sel[1]+"%"],["Parcels",sel[2]],["Flood-risk parcels",Math.round(100-sel[1]/1.4)+"%"],["Dispute rate",(9-sel[1]/14).toFixed(1)+" / 1k"]].map(([a,b])=>(<div key={a} className="flex justify-between border-b border-slate-100 pb-2"><dt className="text-slate-500">{a}</dt><dd className="font-semibold">{b}</dd></div>))}</dl></div>
   <div className="card text-xs"><b className="text-navy">Legend</b>{[["#0F2A4A","> 90%"],["#2563eb","80–90%"],["#E8791B","70–80%"],["#dc2626","< 70%"]].map(([c,t])=><div key={t} className="mt-2 flex items-center gap-2"><i className="h-3 w-3 rounded-full" style={{background:c}}/>{t}</div>)}</div></div></div></>)}
