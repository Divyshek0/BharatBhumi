"use client";
import {useRef,useEffect,useState} from "react";import {Head,Guard,Badge} from "@/components/ui";import {api} from "@/lib/api";
type Src={type:string;title:string;url?:string;score:number;snippet:string};type Msg={r:"u"|"a";t:string;src?:Src[]};
const ideas=["Which datasets cover climate vulnerability?","Research on land disputes and machine learning","What reforms reduce mutation delays?","Drone surveys for land records"];
export default function P(){const [m,setM]=useState<Msg[]>([{r:"a",t:"Hi! I search the platform's ingested documents and datasets and answer with sources. Ask me anything about land governance."}]);const [q,setQ]=useState("");const [busy,setBusy]=useState(false);const end=useRef<HTMLDivElement>(null);
 useEffect(()=>{end.current?.scrollIntoView({behavior:"smooth"})},[m,busy]);
 const ask=async(text:string)=>{if(!text.trim())return;setM(x=>[...x,{r:"u",t:text}]);setQ("");setBusy(true);
  try{const r=await api("/api/research/search",{method:"POST",body:{query:text,top_k:4}});setM(x=>[...x,{r:"a",t:r.answer,src:r.sources}])}catch(e:any){setM(x=>[...x,{r:"a",t:"Search failed: "+e.message}])}setBusy(false)};
 return(<Guard roles={["Researcher","Policy Maker","Administrator"]}><Head title="AI Semantic Search" sub="Ask questions in plain language – answers are grounded in ingested platform data (RAG)"/>
 <div className="card flex h-[620px] flex-col p-0"><div className="flex items-center gap-2 border-b p-4 text-xs text-slate-500"><Badge t="Active"/>Connected to the RAG service · set LLM_API_KEY on the backend for written answers</div>
 <div className="flex-1 space-y-4 overflow-y-auto p-5">{m.map((x,i)=>(<div key={i} className={`flex ${x.r==="u"?"justify-end":""}`}><div className={`max-w-[80%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm ${x.r==="u"?"bg-navy text-white":"bg-slate-100"}`}>{x.t}
  {x.src&&<div className="mt-3 space-y-2">{x.src.map(s=>(<div key={s.title} className="rounded-xl bg-white p-3 text-slate-700 shadow-sm"><div className="flex items-center gap-2"><Badge t={s.type||"Doc"}/><b className="text-navy">{s.title}</b><span className="ml-auto text-xs text-emerald-600">{Math.round(s.score*100)}%</span></div><div className="mt-1 text-xs text-slate-500">{s.snippet}</div></div>))}</div>}</div></div>))}
  {busy&&<div className="text-sm text-slate-400">Searching sources…</div>}<div ref={end}/></div>
 <div className="border-t p-4"><div className="mb-3 flex flex-wrap gap-2">{ideas.map(i=><button key={i} onClick={()=>ask(i)} className="rounded-full border border-slate-200 px-3 py-1 text-xs hover:bg-slate-50">{i}</button>)}</div>
 <div className="flex gap-2"><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&ask(q)} placeholder="Ask about datasets, papers, policies…" className="inp"/><button onClick={()=>ask(q)} className="btn">Send</button></div></div></div></Guard>)}
