CREATE EXTENSION IF NOT EXISTS postgis;
CREATE TABLE users(id BIGSERIAL PRIMARY KEY,email VARCHAR(255) UNIQUE NOT NULL,name VARCHAR(255) NOT NULL,org VARCHAR(255),password_hash VARCHAR(100) NOT NULL,role VARCHAR(20) NOT NULL);
CREATE TABLE datasets(id BIGSERIAL PRIMARY KEY,title TEXT NOT NULL,source TEXT,category TEXT,access VARCHAR(20) DEFAULT 'PUBLIC',state TEXT,records_count BIGINT,geom geometry(Point,4326),updated_at DATE,UNIQUE(title,source));
CREATE TABLE documents(id BIGSERIAL PRIMARY KEY,title TEXT,doc_type TEXT,source_url TEXT UNIQUE,content TEXT);
CREATE INDEX datasets_geom ON datasets USING GIST(geom);
