INSERT INTO datasets(title,source,category,access,records_count,updated_at) VALUES
('Village Cadastral Maps','State Revenue Depts','Land Records','PUBLIC',640000,'2026-09-01'),
('LULC 2025 (30 m)','ISRO / NRSC','Remote Sensing','PUBLIC',NULL,'2026-08-15'),
('Watershed Boundaries','DoLR','Geospatial','PUBLIC',320000,'2026-07-20'),
('Climate Vulnerability Index','IMD / MoEFCC','Climate','PUBLIC',736,'2026-08-10'),
('Urban Sprawl Change Maps','NRSC','Remote Sensing','PUBLIC',4041,'2026-08-05'),
('Soil Health Cards','MoA&FW','Agriculture','PUBLIC',230000000,'2026-08-01'),
('Forest Cover Change','FSI','Remote Sensing','PUBLIC',NULL,'2026-07-01'),
('Flood Inundation Maps','CWC / NRSC','Climate','PUBLIC',28,'2026-08-12'),
('Census Land-holding Data','MoA&FW','Socio-economic','RESEARCHER',21000000,'2026-06-10'),
('Mutation Trends (anonymised)','State Registries','Land Records','RESEARCHER',48000000,'2026-09-05'),
('Land Acquisition Cases','MoRD','Policy','RESEARCHER',110000,'2026-09-02'),
('Property Tax Parcels (Urban)','MoHUA','Land Records','RESEARCHER',2900,'2026-09-03')
ON CONFLICT DO NOTHING;
INSERT INTO documents(title,doc_type,source_url,content) VALUES
('Land Record Digitisation and Dispute Rates','Paper','sample://paper-1','Sample summary: states with higher land record digitisation and automated mutation saw fewer land disputes and shorter mutation delays over five years.'),
('Remote Sensing for Urban-Rural Land Transitions','Paper','sample://paper-2','Sample summary: satellite time series and land use land cover maps can track urban expansion into agricultural land and support planning.'),
('Unified Land Titling Reform','Policy','sample://policy-1','Sample summary: a conclusive titling registry aims to reduce ownership disputes and simplify mutation, with pilots showing lower pendency.'),
('Digital Mutation in 7 Days','Policy','sample://policy-2','Sample summary: automatic mutation on registration reduced pendency in pilot states and cut mutation time significantly.'),
('Climate-Resilient Zoning Proposal','Policy','sample://policy-3','Sample summary: restricting construction in flood-prone parcels using flood inundation maps and the climate vulnerability index can lower flood losses.'),
('Drone Surveys under SVAMITVA','Paper','sample://paper-3','Sample summary: drone-based village habitation mapping produced accurate property records and reduced property disputes in rural areas.'),
('Predicting Dispute Hotspots with Machine Learning','Paper','sample://paper-4','Sample summary: machine learning on mutation, litigation and socio-economic data can identify districts likely to face rising land disputes.'),
('Women Co-ownership Incentive','Policy','sample://policy-4','Sample summary: stamp duty rebates for joint titles increased women co-ownership of land in pilot states.')
ON CONFLICT DO NOTHING;

