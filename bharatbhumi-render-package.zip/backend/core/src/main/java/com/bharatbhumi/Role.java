package com.bharatbhumi; public enum Role{PUBLIC,RESEARCHER,POLICY_MAKER,ADMIN}
