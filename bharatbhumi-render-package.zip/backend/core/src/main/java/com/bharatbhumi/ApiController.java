package com.bharatbhumi;
import org.springframework.beans.factory.annotation.Value;import org.springframework.http.MediaType;import org.springframework.jdbc.core.JdbcTemplate;import org.springframework.web.bind.annotation.*;import org.springframework.web.client.RestClient;
import java.util.*;
@RestController public class ApiController{
 private final JdbcTemplate db;private final RestClient ai;private final UserRepo users;
 public ApiController(JdbcTemplate d,UserRepo u,@Value("${app.ai.url}") String url,@Value("${app.ai.key}") String key){db=d;users=u;ai=RestClient.builder().baseUrl(url).defaultHeader("X-Internal-Key",key).build();}
 @GetMapping("/api/public/datasets") public List<Map<String,Object>> pub(){return db.queryForList("SELECT id,title,source,category,state,records_count,updated_at,ST_Y(geom) lat,ST_X(geom) lng FROM datasets WHERE access='PUBLIC' ORDER BY updated_at DESC NULLS LAST LIMIT 500");}
 @GetMapping("/api/research/datasets") public List<Map<String,Object>> all(){return db.queryForList("SELECT id,title,source,category,access,state,records_count,updated_at FROM datasets ORDER BY updated_at DESC NULLS LAST LIMIT 1000");}
 @PostMapping("/api/research/search") public Object search(@RequestBody Map<String,Object> b){return call("/search",b);}
 @PostMapping("/api/policy/simulate") public Object simulate(@RequestBody Map<String,Object> b){return call("/simulate",b);}
 @GetMapping("/api/admin/users") public List<Map<String,Object>> list(){return users.findAll().stream().map(u->Map.<String,Object>of("id",u.id,"name",u.name,"email",u.email,"role",u.role.name())).toList();}
 private Object call(String p,Map<String,Object> b){return ai.post().uri(p).contentType(MediaType.APPLICATION_JSON).body(b).retrieve().body(Object.class);}}
