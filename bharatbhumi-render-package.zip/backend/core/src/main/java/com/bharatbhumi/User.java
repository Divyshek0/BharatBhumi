package com.bharatbhumi;
import jakarta.persistence.*;
@Entity @Table(name="users") public class User{
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 @Column(unique=true,nullable=false) public String email;
 public String name; public String org;
 @Column(name="password_hash") public String passwordHash;
 @Enumerated(EnumType.STRING) public Role role;}
