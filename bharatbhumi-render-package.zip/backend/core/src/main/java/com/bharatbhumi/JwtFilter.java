package com.bharatbhumi;
import io.jsonwebtoken.*;import jakarta.servlet.*;import jakarta.servlet.http.*;import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;import org.springframework.security.core.context.SecurityContextHolder;import org.springframework.stereotype.Component;import org.springframework.web.filter.OncePerRequestFilter;
import java.io.IOException;import java.util.List;
@Component public class JwtFilter extends OncePerRequestFilter{
 private final JwtService jwt;public JwtFilter(JwtService j){jwt=j;}
 @Override protected void doFilterInternal(HttpServletRequest q,HttpServletResponse s,FilterChain c)throws ServletException,IOException{
  String h=q.getHeader("Authorization");
  if(h!=null&&h.startsWith("Bearer ")){try{Claims cl=jwt.parse(h.substring(7));
   SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(cl.getSubject(),null,List.of(new SimpleGrantedAuthority("ROLE_"+cl.get("role",String.class)))));
  }catch(JwtException|IllegalArgumentException e){}}
  c.doFilter(q,s);}}
