package com.bharatbhumi;
import org.springframework.beans.factory.annotation.Value;import org.springframework.boot.CommandLineRunner;import org.springframework.security.crypto.password.PasswordEncoder;import org.springframework.stereotype.Component;
@Component public class Bootstrap implements CommandLineRunner{
 private final UserRepo r;private final PasswordEncoder e;@Value("${app.admin.email}") String mail;@Value("${app.admin.password}") String pw;
 public Bootstrap(UserRepo r,PasswordEncoder e){this.r=r;this.e=e;}
 public void run(String... a){if(r.existsByEmail(mail))return;User u=new User();u.email=mail;u.name="Administrator";u.org="BharatBhumi";u.role=Role.ADMIN;u.passwordHash=e.encode(pw);r.save(u);}}
