package com.bharatbhumi;
import org.springframework.context.annotation.*;import org.springframework.http.HttpMethod;import org.springframework.security.config.Customizer;import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.*;import java.util.List;
@Configuration public class SecurityConfig{
 @Bean SecurityFilterChain chain(HttpSecurity h,JwtFilter f)throws Exception{
  h.csrf(c->c.disable()).cors(Customizer.withDefaults()).sessionManagement(s->s.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
   .authorizeHttpRequests(a->a.requestMatchers(HttpMethod.OPTIONS,"/**").permitAll()
    .requestMatchers("/api/auth/**","/api/public/**","/actuator/health").permitAll()
    .requestMatchers("/api/research/**").hasAnyRole("RESEARCHER","POLICY_MAKER","ADMIN")
    .requestMatchers("/api/policy/**").hasAnyRole("POLICY_MAKER","ADMIN")
    .requestMatchers("/api/admin/**").hasRole("ADMIN").anyRequest().authenticated())
   .addFilterBefore(f,UsernamePasswordAuthenticationFilter.class);return h.build();}
 @Bean PasswordEncoder enc(){return new BCryptPasswordEncoder();}
 @Bean CorsConfigurationSource cors(){var c=new CorsConfiguration();c.setAllowedOrigins(List.of("http://localhost:3000"));c.setAllowedMethods(List.of("*"));c.setAllowedHeaders(List.of("*"));var s=new UrlBasedCorsConfigurationSource();s.registerCorsConfiguration("/**",c);return s;}}
