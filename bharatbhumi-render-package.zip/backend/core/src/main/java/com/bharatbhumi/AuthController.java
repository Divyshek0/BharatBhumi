package com.bharatbhumi;
import jakarta.validation.Valid;import jakarta.validation.constraints.*;import org.springframework.http.ResponseEntity;import org.springframework.security.crypto.password.PasswordEncoder;import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController @RequestMapping("/api/auth") public class AuthController{
 record RegisterReq(@NotBlank String name,@Email @NotBlank String email,@Size(min=8) String password,String org,@NotNull Role role){}
 record LoginReq(@NotBlank String email,@NotBlank String password){}
 private final UserRepo repo;private final PasswordEncoder enc;private final JwtService jwt;
 public AuthController(UserRepo r,PasswordEncoder e,JwtService j){repo=r;enc=e;jwt=j;}
 private Map<String,Object> view(User u){return Map.of("name",u.name,"email",u.email,"role",u.role.name(),"org",u.org==null?"":u.org);}
 @PostMapping("/register") public ResponseEntity<?> register(@Valid @RequestBody RegisterReq r){
  if(r.role()==Role.ADMIN)return ResponseEntity.status(403).body(Map.of("error","This role cannot be self-registered"));
  if(repo.existsByEmail(r.email()))return ResponseEntity.status(409).body(Map.of("error","Email already registered"));
  User u=new User();u.email=r.email();u.name=r.name();u.org=r.org();u.role=r.role();u.passwordHash=enc.encode(r.password());repo.save(u);
  return ResponseEntity.status(201).body(Map.of("message","Account created. Please sign in."));}
 @PostMapping("/login") public ResponseEntity<?> login(@Valid @RequestBody LoginReq r){
  var u=repo.findByEmail(r.email()).filter(x->enc.matches(r.password(),x.passwordHash));
  if(u.isEmpty())return ResponseEntity.status(401).body(Map.of("error","Invalid email or password"));
  return ResponseEntity.ok(Map.of("token",jwt.create(u.get()),"user",view(u.get())));}
 @GetMapping("/me") public ResponseEntity<?> me(org.springframework.security.core.Authentication a){
  return repo.findByEmail(a.getName()).<ResponseEntity<?>>map(u->ResponseEntity.ok(view(u))).orElse(ResponseEntity.status(401).build());}
 record UpdateReq(@NotBlank String name,String org){}
 @PutMapping("/me") public ResponseEntity<?> update(@Valid @RequestBody UpdateReq r,org.springframework.security.core.Authentication a){
  return repo.findByEmail(a.getName()).<ResponseEntity<?>>map(u->{u.name=r.name();u.org=r.org();repo.save(u);return ResponseEntity.ok(view(u));}).orElse(ResponseEntity.status(401).build());}
 @DeleteMapping("/me") public ResponseEntity<?> del(org.springframework.security.core.Authentication a){
  var u=repo.findByEmail(a.getName());if(u.isEmpty())return ResponseEntity.status(401).build();
  if(u.get().role==Role.ADMIN)return ResponseEntity.status(403).body(Map.of("error","Admin account cannot be deleted"));
  repo.delete(u.get());return ResponseEntity.noContent().build();}}
