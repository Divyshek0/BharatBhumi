package com.bharatbhumi;
import io.jsonwebtoken.*;import io.jsonwebtoken.security.Keys;import org.springframework.beans.factory.annotation.Value;import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;import java.nio.charset.StandardCharsets;import java.util.Date;
@Service public class JwtService{
 private final SecretKey key;private final long ttl;
 public JwtService(@Value("${app.jwt.secret}") String s,@Value("${app.jwt.ttl-minutes}") long m){key=Keys.hmacShaKeyFor(s.getBytes(StandardCharsets.UTF_8));ttl=m;}
 public String create(User u){return Jwts.builder().subject(u.email).claim("role",u.role.name()).issuedAt(new Date()).expiration(new Date(System.currentTimeMillis()+ttl*60000)).signWith(key).compact();}
 public Claims parse(String t){return Jwts.parser().verifyWith(key).build().parseSignedClaims(t).getPayload();}}
