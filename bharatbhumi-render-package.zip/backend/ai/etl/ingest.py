"""ETL: fetch open data (e.g. data.gov.in resources) -> standardise -> upsert into Postgres -> embed.
Env: DATABASE_URL, DATA_GOV_API_KEY, RESOURCE_IDS=id1,id2, AI_URL (defaults to http://localhost:8000), AI_INTERNAL_KEY
Uses each source's official API; respect its terms of use."""
import os, requests, pandas as pd, psycopg
AI_URL = os.getenv("AI_URL", "http://localhost:8000")
AI_KEY = os.getenv("AI_INTERNAL_KEY", "dev-internal-key")
STATES = {"orissa": "Odisha", "uttaranchal": "Uttarakhand", "nct of delhi": "Delhi", "andaman & nicobar islands": "Andaman and Nicobar Islands"}
def std_state(s):
    s = str(s).strip(); return STATES.get(s.lower(), s.title())
def fetch(rid):
    r = requests.get(f"https://api.data.gov.in/resource/{rid}", params={"api-key": os.environ["DATA_GOV_API_KEY"], "format": "json", "limit": 500}, timeout=60)
    r.raise_for_status(); return r.json()
def main():
    doc_ids = []
    with psycopg.connect(os.environ["DATABASE_URL"]) as c:
        for rid in os.environ["RESOURCE_IDS"].split(","):
            j = fetch(rid.strip()); df = pd.DataFrame(j.get("records", []))
            if df.empty: continue
            df.columns = [x.strip().lower().replace(" ", "_") for x in df.columns]
            df = df.drop_duplicates()
            st = next((k for k in df.columns if "state" in k), None)
            if st: df[st] = df[st].map(std_state)
            title = j.get("title", rid); src = j.get("org", ["data.gov.in"])
            source_name = ",".join(src) if isinstance(src, list) else str(src)
            c.execute("INSERT INTO datasets(title,source,category,state,records_count,updated_at) VALUES(%s,%s,%s,%s,%s,now()) ON CONFLICT(title,source) DO UPDATE SET records_count=EXCLUDED.records_count,updated_at=now()",
                      (title, source_name, "Open Data", None, len(df)))
            row = c.execute("INSERT INTO documents(title,doc_type,source_url,content,source_name) VALUES(%s,'Dataset',%s,%s,%s) "
                             "ON CONFLICT(source_url) DO UPDATE SET content=EXCLUDED.content RETURNING id",
                             (title, f"https://api.data.gov.in/resource/{rid}", df.head(50).to_csv(index=False), source_name)).fetchone()
            doc_ids.append(row[0])
        c.commit()
    r = requests.post(f"{AI_URL}/reembed_all", headers={"X-Internal-Key": AI_KEY}, timeout=300)
    print("Ingested", len(doc_ids), "documents. Embedding result:", r.json())
if __name__ == "__main__": main()
