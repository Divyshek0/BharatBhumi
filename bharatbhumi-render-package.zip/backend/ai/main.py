import os, psycopg, httpx
from fastapi import FastAPI, Header, HTTPException
from pydantic import BaseModel
from pgvector.psycopg import register_vector
from sentence_transformers import SentenceTransformer

app = FastAPI(title="BharatBhumi AI")
KEY = os.getenv("AI_INTERNAL_KEY", "dev-internal-key")
_model = None
def model():
    global _model
    if _model is None:
        _model = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2")  # 384-dim, runs on CPU
    return _model

def db():
    c = psycopg.connect(os.environ["DATABASE_URL"])
    register_vector(c)
    return c

def guard(k):
    if k != KEY:
        raise HTTPException(401, "internal only")

class Sim(BaseModel):
    digitisation: float = 60; automation: float = 50; urbanisation: float = 30; climate_risk: float = 40; years: int = 5

@app.post("/simulate")
def simulate(r: Sim, x_internal_key: str = Header(None)):
    guard(x_internal_key); out = []
    for y in range(1, r.years + 1):
        f = y / r.years
        d = (-(0.30 * r.digitisation + 0.25 * r.automation) + 0.12 * r.urbanisation) * f
        m = max(5, 60 - 0.45 * r.automation * f)
        fl = (0.15 * r.climate_risk - 0.10 * r.digitisation) * f
        out.append({"year": y, "disputes_change_pct": round(d, 1), "band": [round(d * 1.15, 1), round(d * 0.85, 1)], "mutation_days": round(m), "flood_loss_change_pct": round(fl, 1)})
    return {"model": "explainable-linear-v0", "inputs": r.model_dump(), "projection": out}

class Q(BaseModel):
    query: str; top_k: int = 4

@app.post("/search")
async def search(q: Q, x_internal_key: str = Header(None)):
    guard(x_internal_key)
    qv = model().encode(q.query).tolist()
    with db() as c:
        rows = c.execute(
            "SELECT title, doc_type, source_url, content, 1 - (embedding <=> %s) AS score "
            "FROM documents WHERE embedding IS NOT NULL ORDER BY embedding <=> %s LIMIT %s",
            (qv, qv, q.top_k)).fetchall()
    if not rows:
        return {"answer": "No embedded documents yet. Run the ETL to ingest and embed sources.", "sources": []}
    src = [{"title": t, "type": ty, "url": u, "score": round(float(s), 3), "snippet": (ct or "")[:300]} for t, ty, u, ct, s in rows if s > 0.2]
    answer = "Top matches listed below."
    if os.getenv("LLM_API_KEY") and src:
        ctx = "\n\n".join(f"[{i+1}] {x['title']}: {x['snippet']}" for i, x in enumerate(src))
        async with httpx.AsyncClient(timeout=60) as h:
            resp = await h.post("https://api.anthropic.com/v1/messages",
                headers={"x-api-key": os.environ["LLM_API_KEY"], "anthropic-version": "2023-06-01"},
                json={"model": os.getenv("LLM_MODEL", "claude-sonnet-4-6"), "max_tokens": 600,
                      "messages": [{"role": "user", "content": f"Answer using only these sources and cite as [n].\n\n{ctx}\n\nQuestion: {q.query}"}]})
            answer = resp.json()["content"][0]["text"]
    return {"answer": answer, "sources": src}

class Embed(BaseModel):
    id: int; text: str

@app.post("/embed_one")
def embed_one(e: Embed, x_internal_key: str = Header(None)):
    guard(x_internal_key)
    vec = model().encode(e.text).tolist()
    with db() as c:
        c.execute("UPDATE documents SET embedding=%s WHERE id=%s", (vec, e.id))
        c.commit()
    return {"ok": True}

@app.post("/reembed_all")
def reembed_all(x_internal_key: str = Header(None)):
    guard(x_internal_key)
    with db() as c:
        rows = c.execute("SELECT id, title, content FROM documents WHERE embedding IS NULL").fetchall()
        for i, t, ct in rows:
            vec = model().encode(f"{t}. {ct or ''}").tolist()
            c.execute("UPDATE documents SET embedding=%s WHERE id=%s", (vec, i))
        c.commit()
    return {"embedded": len(rows)}
