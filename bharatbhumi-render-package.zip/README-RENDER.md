# BharatBhumi on Render

This bundle contains the frontend and both backend services in one repository layout, plus `render.yaml` to provision the services and Postgres together.

## Deploy

1. Create an empty **private** Git repository with your Git provider, then push the contents of this folder from your computer:
   ```sh
   git init -b main
   git add .
   git commit -m "Prepare BharatBhumi for Render"
   git remote add origin <your-private-repository-url>
   git push -u origin main
   ```
2. Sign in to Render, choose **New → Blueprint**, and connect that repository. Render will detect `render.yaml`.
3. During Blueprint setup, provide a dedicated admin email and a strong admin password when prompted. Render generates the JWT and internal AI secrets.
4. Review the listed resources and deploy the Blueprint. Open the `bharatbhumi-frontend` service URL when deployment finishes.

The files are arranged as a single repo because Render needs the frontend, API and AI source available together for the Blueprint.

The AI API is protected by a generated internal key. The frontend proxies `/api/*` requests to the core service over Render's private network. `LLM_API_KEY` is optional; semantic search still returns matching source snippets without it.

## Preview-tier limitations

All services are set to Render's free plan for a no-cost preview. Free web services sleep when idle, and the free Postgres database expires after 30 days; after the grace period, Render deletes the database and its data. Upgrade the database before storing anything that needs to be kept. Free services are intended for previews, not production workloads. See [Render's free-instance limits](https://render.com/docs/free).

The first semantic-search request loads the embedding model and can take longer than later requests. The current project also needs data ingestion before its AI search returns populated research results.
